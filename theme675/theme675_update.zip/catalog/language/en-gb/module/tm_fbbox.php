<?php
// Heading
$_['heading_title']    = 'Facebook:';

// Text
$_['text_edit']        = 'Edit Account';
