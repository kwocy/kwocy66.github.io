<?php
/**
 * @version		$Id: item.php 3898 2015-03-28 12:05:05Z mic $
 * @package		Language Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Pro Stück';

// Text
$_['text_shipping']		= 'Versand';
$_['text_success']		= 'Datensatz erfolgreich bearbeitet';
$_['text_edit']			= 'Bearbeiten';

// Entry
$_['entry_cost']		= 'Kosten';
$_['entry_tax_class']	= 'Steuerklasse';
$_['entry_geo_zone']	= 'Geozone';
$_['entry_status']		= 'Status';
$_['entry_sort_order']	= 'Reihenfolge';

// Error
$_['error_permission']	= 'Keine Rechte für diese Aktion';