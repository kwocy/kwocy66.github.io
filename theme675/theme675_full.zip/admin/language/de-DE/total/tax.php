<?php
/**
 * @version		$Id: tax.php 3857 2015-03-02 20:53:49Z mic $
 * @package		Language Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Steuern';

// Text
$_['text_total']		= 'Kassamodule';
$_['text_success']		= 'Datensatz erfolgreich bearbeitet';
$_['text_edit']			= 'Bearbeiten';

// Entry
$_['entry_status']		= 'Status';
$_['entry_sort_order']	= 'Reihenfolge';

// Error
$_['error_permission']	= 'Keine Rechte für diese Aktion';