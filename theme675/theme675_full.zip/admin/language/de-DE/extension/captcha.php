<?php
/**
 * @version		$Id: captcha.php 4093 2015-10-15 09:39:04Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2015 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Captcha';

// Text
$_['text_success']		= 'Einstellungen erfolgreich bearbeitet';
$_['text_list']			= 'Übersicht';

// Column
$_['column_name']		= 'Name';
$_['column_status']		= 'Status';
$_['column_action']		= 'Aktion';

// Error
$_['error_permission']	= 'Keine Rechte für diese Aktion';