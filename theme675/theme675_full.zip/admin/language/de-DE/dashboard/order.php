<?php
/**
 * @version		$Id: order.php 3755 2014-10-02 08:55:51Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Aufträge Gesamt';

// Text
$_['text_view']		= 'Mehr ..';